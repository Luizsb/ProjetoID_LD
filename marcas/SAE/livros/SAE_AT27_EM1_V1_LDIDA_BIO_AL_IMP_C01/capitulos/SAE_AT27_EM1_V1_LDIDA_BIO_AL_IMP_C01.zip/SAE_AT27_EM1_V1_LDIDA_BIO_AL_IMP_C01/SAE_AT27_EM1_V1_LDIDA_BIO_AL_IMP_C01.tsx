// @ld-export-metadata: {"chapterNumber":2,"chapterTitle":"17. C4:H14 (UEMA) Analise a imagem para responder à questão.","startPage":11,"pageCount":1,"componentName":"BookCap02","exportFolderName":"livro_digital_C02"}
import { publicUrl } from '../lib/publicUrl';
import Poster from '../components/Poster';
import Chapter from '../components/Chapter';
import TeacherButton from '../components/TeacherButton';
import Header from '../components/Header';
import Pagination from '../components/Pagination';
import Footer from '../components/Footer';
import { usePagination } from '../hooks/usePagination';
import { useScrollPosition } from '../hooks/useScrollPosition';
import QuestionRenderer from '../components/QuestionRenderer';
import { TeacherAnswers } from '../components/TeacherAnswers';
import { useUserAnswers } from '../hooks/useUserAnswers';
import { useState } from 'react';
import type { Question } from '../types/questions';

const SHOW_TEACHER_BUTTON = true;
const START_PAGE = 11;

const chapterQuestions: Question[] = [
  {
    id: 'cap2_q1_a',
    type: 'text-input',
    question: 'a) selecione uma organela citoplasmática comum aos dois tipos celulares, com sua respectiva função.',
    placeholder: 'Digite aqui...',
    correctAnswer: 'Espera-se que o aluno cite organelas como mitocôndria (respiração celular), ribossomos (síntese proteica), retículo endoplasmático (transporte e síntese de substâncias) ou complexo golgiense (secreção celular).',
  },
  {
    id: 'cap2_q1_b',
    type: 'text-input',
    question: 'b) cite duas estruturas ou organelas celulares que permitem ao estudante identificar a figura B como uma célula vegetal.',
    placeholder: 'Digite aqui...',
    correctAnswer: 'Espera-se que o aluno cite a parede celular, os cloroplastos ou o grande vacúolo central.',
  }
];

function BookCap02() {
  const { userAnswers, handleAnswerChange } = useUserAnswers();
  const { currentPage, scrollToTop } = usePagination(START_PAGE);
  const [showTeacherView] = useState(false);
  useScrollPosition();

  const getQuestionById = (questionId: string) =>
    chapterQuestions.find((question) => question.id === questionId)!;

  return (
    <div className="marca-sae min-h-screen w-full bg-gray-200">
      <div
        className="mx-auto w-full overflow-visible bg-white shadow-2xl md:max-w-[63%]"
        style={{ marginLeft: 'auto', marginRight: 'auto' }}
      >
        <Header
          marca="sae"
          badge="CAPÍTULO"
          chapterNumber={2}
          chapterTitle="17. C4:H14 (UEMA) Analise a imagem para responder à questão."
        />

        <Pagination currentPage={START_PAGE} />

        <Poster
          imageSrc="images/page_11_img_320_284.png"
          alt="Diagrama comparativo de uma célula animal (esquerda) e uma célula vegetal (direita), destacando suas organelas e estruturas distintas."
          creditLine1=""
          creditLine2="Fonte: https://pt.aliexpress.com/item/Periodic-Table-SA-full-dyesubbed-Keycaps (adaptado)."
        />

        <div className="p-8 md:p-12">
          <div className="my-6">
            <TeacherButton
              visible={SHOW_TEACHER_BUTTON}
              content={
                <TeacherAnswers questions={chapterQuestions} />
              }
            />
          </div>

          <Chapter
            title=""
            content={
              <>
                <p className="mb-4 indent-6">
                  Ao realizar um estudo de biologia, um aluno deparou-se com duas figuras de células: a figura A, representando uma célula animal, e a figura B, uma célula vegetal. De acordo com as figuras,
                </p>

                <QuestionRenderer
                  question={getQuestionById('cap2_q1_a')}
                  userAnswers={userAnswers}
                  onAnswerChange={handleAnswerChange}
                  showResults={showTeacherView}
                />

                <QuestionRenderer
                  question={getQuestionById('cap2_q1_b')}
                  userAnswers={userAnswers}
                  onAnswerChange={handleAnswerChange}
                  showResults={showTeacherView}
                />

                <div className="my-8 rounded-[20px] bg-[#d7dcef] p-6 md:p-8">
                  <h3 className="mb-4 font-bold text-[#80298F]">GABARITO ONLINE</h3>
                  <ol className="ml-6 list-decimal space-y-2 text-black">
                    <li>Abra a câmera do celular ou faça download de qualquer aplicativo de leitura de QR Code.</li>
                    <li>Aponte para o QR Code ao lado para acessar o gabarito das questões.</li>
                  </ol>
                </div>
              </>
            }
          />
        </div>

        <Footer />
      </div>

      {currentPage > START_PAGE && (
        <button
          onClick={scrollToTop}
          className="fixed bottom-16 right-4 z-40 p-3 hover:scale-110 transition-all"
          title="Voltar ao início do capítulo"
        >
          <img src={publicUrl('images/setaTopo.svg')} alt="Voltar ao início do capítulo" />
        </button>
      )}
    </div>
  );
}

export default BookCap02;